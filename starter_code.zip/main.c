#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vector.h"

int main( int argc, char* argv[] )
{
	if ( argc != 3 )
	{
		fprintf(stderr, "Usage: vectors <input-file> <output-file>\n");
		exit(1);
	}
	
	FILE* in;
	in = fopen(argv[1], "r");
	FILE* out;
	out = fopen(argv[2], "w");

	char command[10]; //this is big enough to hold the word 'decompose'
	int angle1, magnitude1, angle2, magnitude2, xcoord, ycoord;
	double result_mag, result_dir, result_xcoord, result_ycoord;
	double x1, y1, x2, y2;

        fprintf(out, "Command       X-Part      Y-Part   Magnitude Direction\n" );
        fprintf(out, "------------------------------------------------------\n" );

	fscanf(in, "%s", command );
	while( !feof(in) )
	{
		if ( strcmp( command, "add" ) == 0 )
		{
			fscanf( in, "%d %d %d %d", &magnitude1, &angle1, &magnitude2, &angle2 );
			add( magnitude1, angle1, magnitude2, angle2, &result_mag, &result_dir );
			decompose( magnitude1, angle1, &x1, &y1 );
			decompose( magnitude2, angle2, &x2, &y2 );
			fprintf( out, "one %17.5f%12.5f%10d%11d\n", x1, y1, magnitude1, angle1);
			fprintf( out, "two %17.5f%12.5f%10d%11d\n", x2, y2, magnitude2, angle2);
			fprintf( out, "add %17.5f%12.5f%10.5f%11.5f\n", x1+x2, y1+y2, result_mag, result_dir );
		}
		else if ( strcmp( command, "decompose" ) == 0 )
		{
			fscanf(in, "%d %d", &magnitude1, &angle1);
			decompose( magnitude1, angle1, &result_xcoord, &result_ycoord );
                	fprintf( out, "decompose%12.5f%12.5f%10d%11d\n", result_xcoord, result_ycoord, magnitude1, angle1);
		}
		else if ( strcmp( command, "vector" ) == 0 )
		{
			fscanf( in, "%d %d", &xcoord, &ycoord );
			vector( xcoord, ycoord, &result_mag, &result_dir );
                	fprintf( out, "vector%15d%12d%10.5f%11.5f\n", xcoord, ycoord, result_mag, result_dir );
		}
		else
		{
			fprintf( stderr, "Unknown command: %s\n", command );
		}
		fscanf(in, "%s", command );

	}

	fclose(in);
	fclose(out);

	return 0;
}
