#include "vector.h"
/*
 * These are the required functions. Do no change these signatures
 *
 * Other functions you could write might be ones to convert from degrees
 * to radian and from radians to degrees. 
 *
 * I wrote a function that I used to correct the results from atan.
 * I also wrote a function I could use that is one of the 3 required 
 * functions but the data types are doubles instead of ints...
 */

void decompose( int magnitude, int direction, double *xcoord, double *ycoord )
{
}
void vector( int xcoord, int ycoord, double *magnitude, double *direction )
{
}
void add( int mag1, int dir1, int mag2, int dir2, double *mag, double *dir )
{
}


