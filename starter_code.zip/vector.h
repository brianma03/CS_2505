#include <math.h>

/*
 * These are the signatures for the 3 required functions
 */ 

/*
 * This will take a magnitude and direction, or angle, and compute the
 * corresponding x and y components, called xcoord and ycoord. 
 * Notice these are pass-by-pointer. This should indicate that those parameters
 * are expected to change.
 */ 
void decompose( int magnitude, int direction, double *xcoord, double *ycoord );
/*
 * This function does the opposite of the decompose function. Given the 
 * x and y parts of a vector, compute the corresponding magnitude and 
 * direction for the vector.
 */ 
void vector( int xcoord, int ycoord, double *magnitude, double *direction );

/*
 * This function is given two vectors, both in terms of their magnitudes
 * and angles, and returns the resultant vector from adding the two given
 * vectors.
 * Note, this function should use decompose and vector to do the work.
 * You may need to write a version of one of those functions that accepts
 * doubles instead of ints
 */ 
void add( int mag1, int dir1, int mag2, int dir2, double *mag, double *dir );
